<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Classic Calacatta Grey Vein Quartz | Haique Quartz</title>
<meta name="description" content="We Haique Quartz Leading Manufacturer, Supplier & Exporter of Classic Calacatta Grey Vein Quartz in india & USA."/>
<meta name="keywords" content="Calacatta Grey Vein Quartz" />

<?php include_once("../../../head.php");?>
</head>
<body>
<!-- header -->
<div class="internalhead">
	<?php include_once("../../../header.php");?>
</div>
<div class="colldetailbox">
	<div class="container">
		<div class="breadcrumbox">
			<nav aria-label="breadcrumb">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="<?=$baseurl;?>">Home</a></li>
					<li class="breadcrumb-item">Collections</li>
                    <li class="breadcrumb-item">Neo Marble</li>
					<li class="breadcrumb-item"><a href="<?=$baseurl;?>/the-milan-collection/">New York Collection</a></li>
					<li class="breadcrumb-item active" aria-current="page">Lincoin White</li>
				</ol>
			</nav>
		</div>
		<div class="row movileswitch">
			<div class="col-12 col-sm-4 col-md-4">
				<div class="colldtlbox">
					<h5><span>Product</span> Lincoin White</h5>
					<h5><span>Collection</span>New York Collection</h5>
					<h5><span>Finishes</span>
						<ul>
							<li>Gloss</li>
							<li>Leather</li>
							<li>Satin</li>
							<li>Matte</li>
							<li>Honed</li>
							<li>Stone Finish</li>
						</ul>
					</h5>
					<h5><span>Thickness</span>
						<ul>
							<li>15mm</li>
						</ul>
					</h5>
					<h5><span>Slab Size</span>
						<ul>
							<li>3250mm by 1650mm</li>
						</ul>
					</h5>
					<h5><span>Catalog</span>
						<a class="download_brouchure" href="<?=$baseurl;?>/e-brochure.pdf" target="_blank">Download PDF</a>
					</h5>
				</div>
				<div class="Requestbtn">
					<a href="" class="mainbtn color2 RequestYourSample" id="RequestYourSample" data-toggle="modal" data-target=".download_brouchure">
						<img src="<?=$baseurl;?>/img/icons/arrow-black.png">
						Request Your Sample
					</a>
				</div>
			</div>
			<div class="col-12 col-sm-8 col-md-8">
				<div class="collslider">
					<div id="carouselExampleFade2" class="carousel slide carousel-fade" data-ride="carousel">
						<ol class="carousel-indicators">
						    <li data-target="#carouselExampleFade2" data-slide-to="0" class="active">
								<img src="<?=$baseurl;?>/img/collection/the-milan-collection/boticelli-primo-bath.jpg">
						    </li>
							<li data-target="#carouselExampleFade2" data-slide-to="1">
								<img src="<?=$baseurl;?>/img/collection/the-milan-collection/boticelli-primo-kitchen.jpg">
						    </li>
						    <li data-target="#carouselExampleFade2" data-slide-to="2">
						    	<img src="<?=$baseurl;?>/img/collection/the-milan-collection/boticelli-primo-slab.jpg">	
						    </li>
					  	</ol>
						<div class="carousel-inner">
							<div class="carousel-item active">
								<img src="<?=$baseurl;?>/img/collection/the-milan-collection/boticelli-primo-bath.jpg" class="d-block w-100" alt="...">
							</div>
							<div class="carousel-item">
								<img src="<?=$baseurl;?>/img/collection/the-milan-collection/boticelli-primo-kitchen.jpg" class="d-block w-100" alt="...">
							</div>
							<div class="carousel-item">
								<img src="<?=$baseurl;?>/img/collection/the-milan-collection/boticelli-primo-slab.jpg" class="d-block w-100" alt="...">
							</div>
						</div>
						<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
						    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
						    <span class="sr-only">Previous</span>
						  </a>
						  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
						    <span class="carousel-control-next-icon" aria-hidden="true"></span>
						    <span class="sr-only">Next</span>
						  </a>
					</div>
				</div>
			</div>
		</div>	
	</div>
	<div class="prevnext">
		<div class="container">
			<div class="row">	
				<div class="col-6 col-sm-6 col-md-6">
					<!-- firstpage -->
					<div class="prevpervbox">	
						<a href="<?=$baseurl;?>/the-milan-collection/boticelli-nuovo/">Previous</a>
					</div>
				</div>
				<div class="col-6 col-sm-6 col-md-6">
					<!-- lastpage -->
					<div class="prevnextbox">	
						<a href="<?=$baseurl;?>/the-milan-collection/boticelli-ultimo/">Next</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>	
<!-- header -->
<?php include_once("../../../footer.php");?>